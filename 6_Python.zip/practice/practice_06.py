# ============================================================
# 2. 시각화 공통 설정
# ============================================================

import pandas as pd
import platform
import matplotlib.pyplot as plt
import seaborn as sns


# generate_data.py에서 만든 CSV 파일 불러오기
df = pd.read_csv(
    "business_data.csv",
    parse_dates=["기준월"]
)

print("데이터 크기:", df.shape)
print(df.head())

system_name = platform.system()
sns.set_theme(style="whitegrid")
if system_name == "Windows":
    plt.rcParams["font.family"] = "Malgun Gothic"
elif system_name == "Darwin":
    plt.rcParams["font.family"] = "AppleGothic"

plt.rcParams["axes.unicode_minus"] = False


# ============================================================
# 3. 과제용 TODO 템플릿
# 아래 함수는 일부러 미완성 상태입니다. TODO를 채운 뒤 호출하세요.
# ============================================================

def assignment_1(data):
    """과제 1: 결측치와 이상치를 확인하고 국가별 관광객 수를 비교한다."""

    # 1. 결측치 요약
    missing_summary = pd.DataFrame({
        "결측치수": data.isna().sum(),
        "결측률(%)": (data.isna().mean() * 100).round(1)
    })

    print("===== 결측치 요약 =====")
    print(missing_summary)

    # 2. 원본 보호를 위한 복사
    checked = data.copy()

    # 3. 국가·여행구분별로 입출국자 수를 묶는다.
    grouped = checked.groupby(
        ["국가", "여행구분"]
    )["입출국자수"]

    # 4. 그룹별 Q1, Q3, IQR을 계산한다.
    group_q1 = grouped.transform(
        lambda x: x.quantile(0.25)
    )

    group_q3 = grouped.transform(
        lambda x: x.quantile(0.75)
    )

    group_iqr = group_q3 - group_q1

    lower_bound = group_q1 - 1.5 * group_iqr
    upper_bound = group_q3 + 1.5 * group_iqr

    # 5. 이상치 여부를 새로운 컬럼에 저장한다.
    checked["입출국자수_이상치"] = (
        (checked["입출국자수"] < lower_bound)
        | (checked["입출국자수"] > upper_bound)
    )

    outliers = checked[
        checked["입출국자수_이상치"]
    ]

    print("\n===== 입출국자 수 이상치 후보 =====")
    print(outliers[
        ["기준월", "국가", "여행구분", "입출국자수"]
    ])

    # 6. 국가·여행구분별 연간 합계를 구한다.
    country_summary = (
        data.groupby(
            ["국가", "여행구분"],
            as_index=False
        )["입출국자수"]
        .sum()
        .sort_values(
            "입출국자수",
            ascending=False
        )
    )

    print("\n===== 국가별 연간 입출국자 수 =====")
    print(country_summary)

    # 7. 막대그래프를 그린다.
    plt.figure(figsize=(13, 6))

    sns.barplot(
        data=country_summary,
        x="국가",
        y="입출국자수",
        hue="여행구분",
        errorbar=None
    )

    plt.title("국가별 연간 방한·해외여행객 수")
    plt.xlabel("국가")
    plt.ylabel("입출국자 수")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

    return missing_summary, checked, country_summary

def assignment_2(data):
    """과제 2: 체류일수와 지출액의 관계 및 비정상 관측치 탐색."""
    # TODO 1: 두 분석 변수의 결측치가 있는 행을 제외하세요.
    plot_data = ...

    # TODO 2: 색상(hue)은 여행구분, 점 모양(style)은 권역으로 지정하세요.
    plt.figure(figsize=(11, 7))
    # sns.scatterplot(data=..., x=..., y=..., hue=..., style=..., s=..., alpha=...)
    ...

    # TODO 3: 전체 및 여행구분별 상관계수를 계산해 비교하세요.
    overall_corr = ...
    group_corr = ...

    plt.tight_layout()
    plt.show()
    return overall_corr, group_corr


def assignment_3(data):
    """과제 3: 권역별 1인당 지출의 중앙값·분산·이상치 비교."""
    # TODO 1: 지출액 결측치를 제외한 데이터를 준비하세요.
    plot_data = ...

    # TODO 2: 권역별 표본 수, 중앙값, 평균, 표준편차를 요약하세요.
    region_stats = ...

    # TODO 3: x=권역, y=1인당평균지출액, hue=여행구분인 Box Plot을 작성하세요.
    plt.figure(figsize=(12, 6))
    # sns.boxplot(data=..., x=..., y=..., hue=..., showfliers=True)
    ...
    plt.tight_layout()
    plt.show()
    return region_stats


def assignment_4(data):
    """과제 4: 국가·월별 출국/입국 규모 비율을 피벗 히트맵으로 비교."""
    # TODO 1: 기준월을 월 표시용 문자열(예: 2025-01)로 변환하세요.
    working = data.copy()
    working["월"] = ...

    # TODO 2: index=[국가, 월], columns=여행구분, values=입출국자수인 피벗을 만드세요.
    pivot = ...

    # TODO 3: 국민 해외여행객 / 방한 외래객 비율을 계산하세요.
    # 1보다 크면 해당 국가로 나가는 국민이, 1보다 작으면 해당 국가에서 오는 외래객이 더 많습니다.
    pivot["출국_대비_입국_비율"] = ...

    # TODO 4: 국가×월 형태로 다시 피벗하고 히트맵을 작성하세요.
    ratio_heatmap = ...
    plt.figure(figsize=(14, 7))
    # sns.heatmap(ratio_heatmap, cmap="RdBu_r", center=1, annot=False)
    ...
    plt.tight_layout()
    plt.show()
    return ratio_heatmap


if __name__ == "__main__":
    # generate_data.py에서 만든 business_data.csv를 불러와 사용합니다.
    # 과제 함수를 완성한 뒤 아래 주석을 하나씩 해제합니다.

    assignment_1(df)
    # assignment_2(df)
    # assignment_3(df)
    # assignment_4(df)
